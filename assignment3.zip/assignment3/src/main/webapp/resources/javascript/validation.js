function validateForm() {
  // Get the values of the input fields
  const firstName = document.getElementById('firstName').value.trim();
  const lastName = document.getElementById('lastName').value.trim();
  const email = document.getElementById('email').value.trim();
  const password = document.getElementById('psw').value;
  const passwordRepeat = document.getElementById('psw-repeat').value;

  // Define regular expressions for email and password validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$/;

  // Define error messages for each input field
  const firstNameError = 'Please enter your first name';
  const lastNameError = 'Please enter your  last name';
  const emailError = 'Please enter a valid email address';
  const passwordError = 'Password must contain at least 8 characters including at least one uppercase letter, one lowercase letter, and one number';
  const passwordRepeatError = 'Passwords do not match';

  // Initialize an error message variable
  let errorMessage = '';

  // Validate the name field
  if (firstName === '') {
    errorMessage += firstNameError + '\n';
  }
  if (lastName === '') {
    errorMessage += lastNameError + '\n';
  }

  // Validate the email field
  if (!emailRegex.test(email)) {
    errorMessage += emailError + '\n';
  }

  // Validate the password field
  if (!passwordRegex.test(password)) {
    errorMessage += passwordError + '\n';
  }

  // Validate the password repeat field
  if (password !== passwordRepeat) {
    errorMessage += passwordRepeatError + '\n';
  }

  // Display the error message if there are any errors
  if (errorMessage !== '') {
    alert(errorMessage);
    return false;
  }

  return true;
}

// Attach the validation function to the form submit event
const form = document.getElementById('index-form');
form.addEventListener('submit', validateForm);
