const form = document.querySelector('nav form');

form.addEventListener('submit', function(event) {
  event.preventDefault();
  const query = this.querySelector('input[type="text"]').value;
  // do something with the search query (e.g., redirect to a search results page)
});